import 'package:flutter/material.dart';

class rightDrawerPage extends StatelessWidget{

  const rightDrawerPage({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return const Drawer(
      child: Text("right drawer"),
    );
  }
}