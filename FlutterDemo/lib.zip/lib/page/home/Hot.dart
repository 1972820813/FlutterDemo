import 'package:flutter/material.dart';

import '../util/Common.dart';

//热点
class HotPage extends StatefulWidget {
  const HotPage({super.key});

  @override
  State<HotPage> createState() => _HotPage();
}

class _HotPage extends State<HotPage> {

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      child: ListView(
        children: getListView("hot"),
      ),
    );
  }
}
